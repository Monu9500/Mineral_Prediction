// Global variables
let map = null
let rockData = []
let filteredRocks = []
let markers = []
let userMarker = null
let gpsEnabled = false
let userLocation = null
let searchTerm = ""
let loading = true
let mapReady = false
let initAttempts = 0

// Import Leaflet library
const L = window.L

// DOM elements
const searchForm = document.getElementById("searchForm")
const searchInput = document.getElementById("searchInput")
const searchResults = document.getElementById("searchResults")
const resultsCount = document.getElementById("resultsCount")
const clearSearchBtn = document.getElementById("clearSearch")
const gpsToggle = document.getElementById("gpsToggle")
const resetViewBtn = document.getElementById("resetView")
const locationCount = document.getElementById("locationCount")
const searchTermSpan = document.getElementById("searchTerm")
const mapStatus = document.getElementById("mapStatus")
const loadingOverlay = document.getElementById("loadingOverlay")
const errorOverlay = document.getElementById("errorOverlay")
const errorMessage = document.getElementById("errorMessage")
const retryButton = document.getElementById("retryButton")
const attemptCounter = document.getElementById("attemptCounter")

// Initialize the application
document.addEventListener("DOMContentLoaded", async () => {
  try {
    console.log("Starting application initialization...")

    // Wait for DOM to be ready
    await new Promise((resolve) => setTimeout(resolve, 100))

    // Initialize map
    await initializeMap()

    // Load rock data
    await loadRockData()

    // Setup event listeners
    setupEventListeners()

    hideLoading()
    console.log("Application initialization complete!")
  } catch (error) {
    console.error("Failed to initialize application:", error)
    showError(`Failed to load map: ${error.message}`)
  }
})

// Initialize the map
async function initializeMap() {
  return new Promise((resolve, reject) => {
    try {
      initAttempts++
      console.log(`Map initialization attempt ${initAttempts}`)
      updateAttemptCounter()

      if (typeof L === "undefined") {
        reject(new Error("Leaflet library not loaded"))
        return
      }

      const mapContainer = document.getElementById("map")
      if (!mapContainer) {
        reject(new Error("Map container not found"))
        return
      }

      // Clear any existing map
      if (map) {
        map.remove()
        map = null
      }

      console.log("Creating Leaflet map...")

      // Create map
      map = L.map("map", {
        center: [20, 0],
        zoom: 2,
        minZoom: 1,
        maxZoom: 18,
        zoomControl: true,
        attributionControl: true,
        preferCanvas: false,
        worldCopyJump: true,
      })

      // Add OpenStreetMap tiles
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 18,
        tileSize: 256,
        zoomOffset: 0,
      }).addTo(map)

      mapReady = true
      showMapStatus()

      console.log("Map created successfully!")

      // Force map to resize
      setTimeout(() => {
        map.invalidateSize(true)
        console.log("Map size invalidated")
      }, 100)

      resolve()
    } catch (error) {
      console.error("Map initialization error:", error)
      reject(error)
    }
  })
}

// Load rock data from Python backend
async function loadRockData() {
  try {
    console.log("Loading rock data...")

    const response = await fetch("http://localhost:8000/api/rocks")

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`)
    }

    const data = await response.json()

    if (!Array.isArray(data)) {
      throw new Error("Invalid data format")
    }

    console.log(`Loaded ${data.length} rock locations`)
    rockData = data
    filteredRocks = data
    updateLocationCount()
  } catch (error) {
    console.error("Error loading rock data:", error)

    // Use sample data as fallback
    const sampleData = [
      { Id: "1", Place: "Grand Canyon, Arizona", Rocks: "Sandstone", Latitude: 36.1069, Longitude: -112.1129 },
      { Id: "2", Place: "Yosemite, California", Rocks: "Granite", Latitude: 37.8651, Longitude: -119.5383 },
      { Id: "3", Place: "Mount Rushmore, South Dakota", Rocks: "Granite", Latitude: 43.8791, Longitude: -103.4591 },
    ]

    rockData = sampleData
    filteredRocks = sampleData
    updateLocationCount()
    console.log("Using sample rock data")
  }
}

// Setup event listeners
function setupEventListeners() {
  // Search form
  searchForm.addEventListener("submit", handleSearch)

  // Clear search
  clearSearchBtn.addEventListener("click", clearSearch)

  // GPS toggle
  gpsToggle.addEventListener("click", handleGpsToggle)

  // Reset view
  resetViewBtn.addEventListener("click", resetMapView)

  // Retry button
  retryButton.addEventListener("click", retryInitialization)
}

// Handle search
function handleSearch(e) {
  e.preventDefault()

  if (!map || typeof L === "undefined") {
    alert("Map is not ready yet. Please wait.")
    return
  }

  searchTerm = searchInput.value.trim()

  if (!searchTerm) {
    filteredRocks = rockData
    clearRockMarkers()
    map.setView([20, 0], 2)
    hideSearchResults()
    updateLocationCount()
    return
  }

  // Filter rocks by search term
  filteredRocks = rockData.filter((rock) => rock?.Rocks?.toLowerCase().includes(searchTerm.toLowerCase()))

  showSearchResults()
  updateLocationCount()
  showRockLocations(filteredRocks)
}

// Show rock locations on map
function showRockLocations(rocks) {
  if (!map || typeof L === "undefined") return

  clearRockMarkers()

  if (rocks.length === 0) {
    alert("No rocks found matching your search")
    return
  }

  // Create custom icon
  const customIcon = L.icon({
    iconUrl:
      "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTIiIGZpbGw9IiNFRjQ0NDQiLz4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iOCIgZmlsbD0iI0RDMjYyNiIvPgo8Y2lyY2xlIGN4PSIxNiIgY3k9IjE2IiByPSI0IiBmaWxsPSIjRkZGRkZGIi8+Cjwvc3ZnPgo=",
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32],
  })

  const newMarkers = []

  rocks.forEach((rock) => {
    if (rock?.Latitude && rock?.Longitude && !isNaN(rock.Latitude) && !isNaN(rock.Longitude)) {
      const marker = L.marker([rock.Latitude, rock.Longitude], { icon: customIcon })
        .addTo(map)
        .bindPopup(`
                    <div style="padding: 12px; min-width: 200px;">
                        <h3 style="margin: 0 0 8px 0; font-weight: bold; color: #1f2937;">${rock.Rocks}</h3>
                        <p style="margin: 0; color: #6b7280;"><strong>Location:</strong> ${rock.Place}</p>
                        <p style="margin: 4px 0 0 0; color: #9ca3af; font-size: 12px;">
                            Lat: ${rock.Latitude.toFixed(4)}, Lng: ${rock.Longitude.toFixed(4)}
                        </p>
                    </div>
                `)

      newMarkers.push(marker)
    }
  })

  markers = newMarkers

  if (newMarkers.length > 0) {
    const group = new L.featureGroup(newMarkers)
    map.fitBounds(group.getBounds().pad(0.1))
  }
}

// Clear search
function clearSearch() {
  searchInput.value = ""
  searchTerm = ""
  filteredRocks = rockData
  clearRockMarkers()
  hideSearchResults()
  updateLocationCount()

  if (map) {
    map.setView([20, 0], 2)
  }
}

// Handle GPS toggle
function handleGpsToggle() {
  if (!map || typeof L === "undefined") return

  if (!gpsEnabled) {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords
          userLocation = [latitude, longitude]
          gpsEnabled = true
          updateGpsButton()

          // Remove existing user marker
          if (userMarker) {
            map.removeLayer(userMarker)
          }

          // Create user location marker
          const userIcon = L.divIcon({
            className: "user-location-marker",
            html: '<div class="user-marker-dot"></div>',
            iconSize: [20, 20],
            iconAnchor: [10, 10],
          })

          userMarker = L.marker([latitude, longitude], { icon: userIcon })
            .addTo(map)
            .bindPopup("<strong>Your Location</strong>")

          map.setView([latitude, longitude], 12)
        },
        (error) => {
          console.error("Geolocation error:", error)
          alert("Unable to get your location. Please check permissions.")
        },
      )
    } else {
      alert("Geolocation is not supported by this browser.")
    }
  } else {
    gpsEnabled = false
    userLocation = null
    updateGpsButton()

    if (userMarker) {
      map.removeLayer(userMarker)
      userMarker = null
    }

    map.setView([20, 0], 2)
  }
}

// Clear rock markers
function clearRockMarkers() {
  if (markers && map) {
    markers.forEach((marker) => {
      map.removeLayer(marker)
    })
    markers = []
  }
}

// Reset map view
function resetMapView() {
  if (map) {
    map.setView([20, 0], 2)
    clearRockMarkers()
  }
}

// Update GPS button
function updateGpsButton() {
  if (gpsEnabled) {
    gpsToggle.className =
      "flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 transition-colors"
    gpsToggle.innerHTML = `
            <svg class="h-4 w-4 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <polygon points="3,11 22,2 13,21 11,13 3,11"></polygon>
            </svg>
            GPS On
        `
  } else {
    gpsToggle.className =
      "flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors"
    gpsToggle.innerHTML = `
            <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <polygon points="3,11 22,2 13,21 11,13 3,11"></polygon>
            </svg>
            GPS Off
        `
  }
}

// Show search results
function showSearchResults() {
  searchResults.classList.remove("hidden")
  resultsCount.textContent = `${filteredRocks.length} locations found`
  searchTermSpan.textContent = `for "${searchTerm}"`
  searchTermSpan.classList.remove("hidden")
}

// Hide search results
function hideSearchResults() {
  searchResults.classList.add("hidden")
  searchTermSpan.classList.add("hidden")
}

// Update location count
function updateLocationCount() {
  locationCount.textContent = `${filteredRocks.length} rock locations`
}

// Show map status
function showMapStatus() {
  mapStatus.classList.remove("hidden")
}

// Hide loading
function hideLoading() {
  loading = false
  loadingOverlay.classList.add("hidden")
}

// Show error
function showError(message) {
  loading = false
  loadingOverlay.classList.add("hidden")
  errorOverlay.classList.remove("hidden")
  errorMessage.textContent = message
}

// Update attempt counter
function updateAttemptCounter() {
  attemptCounter.textContent = `Attempt ${initAttempts}`
}

// Retry initialization
function retryInitialization() {
  errorOverlay.classList.add("hidden")
  loadingOverlay.classList.remove("hidden")
  loading = true
  mapReady = false
  initAttempts = 0

  // Reload the page to start fresh
  window.location.reload()
}
