from flask import Flask, render_template, request, redirect, url_for, session, g, send_from_directory
import sqlite3
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'

DATABASE = os.path.join(os.getcwd(), 'database', 'user.db')

# Ensure database path exists
os.makedirs(os.path.dirname(DATABASE), exist_ok=True)

# Database connection
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

# Login page
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        cur = get_db().execute('SELECT * FROM users WHERE email = ? AND password = ?', (email, password))
        user = cur.fetchone()
        if user:
            session['user'] = dict(user)
            return redirect(url_for('dashboard'))
        else:
            return render_template('login.html', error='Invalid email or password')
    return render_template('login.html')

# Dashboard with role-based access
@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))

    user = session['user']
    level = user['level']

    return render_template('dashboard.html', user=user, level=level)

# Route for map page
@app.route('/map')
def map_page():
    return render_template('map_page.html')

# Insert new rock - only for level 1 and 2
@app.route('/insert_rock', methods=['GET', 'POST'])
def insert_rock():
    if 'user' not in session:
        return redirect(url_for('login'))

    user = session['user']
    if user['level'] not in [1, 2]:
        return "Access denied", 403

    if request.method == 'POST':
        name = request.form['name']
        subtype = request.form['subtype']
        parent_id = request.form['parent_id']
        minerals = request.form['minerals']

        db = get_db()
        db.execute('INSERT INTO rocks (name, subtype, parent_id, minerals) VALUES (?, ?, ?, ?)',
                   (name, subtype, parent_id, minerals))
        db.commit()
        return redirect(url_for('dashboard'))

    return render_template('insert_rock.html')

# Insert new location - only for level 1 and 2
@app.route('/insert_location', methods=['GET', 'POST'])
def insert_location():
    if 'user' not in session:
        return redirect(url_for('login'))

    user = session['user']
    if user['level'] not in [1, 2]:
        return "Access denied", 403

    if request.method == 'POST':
        location_name = request.form['location_name']
        latitude = request.form['latitude']
        longitude = request.form['longitude']

        db = get_db()
        db.execute('INSERT INTO locations (location_name, latitude, longitude) VALUES (?, ?, ?)',
                   (location_name, latitude, longitude))
        db.commit()
        return redirect(url_for('dashboard'))

    return render_template('insert_location.html')

# Create new user - only for level 1
@app.route('/create_user', methods=['GET', 'POST'])
def create_user():
    if 'user' not in session:
        return redirect(url_for('login'))

    user = session['user']
    if user['level'] != 1:
        return "Access denied", 403

    if request.method == 'POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        password = request.form['password']
        level = int(request.form['level'])

        db = get_db()
        db.execute('INSERT INTO users (first_name, last_name, email, password, level) VALUES (?, ?, ?, ?, ?)',
                   (first_name, last_name, email, password, level))
        db.commit()
        return redirect(url_for('dashboard'))

    return render_template('create_user.html')

# Logout
@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)