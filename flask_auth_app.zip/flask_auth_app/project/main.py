from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_required, current_user
import csv
from flask import jsonify, current_app
import os


main = Blueprint('main', __name__)


@main.route('/')
def index():
    return redirect(url_for('auth.login'))

@main.route('/profile')
@login_required
def profile():
    return render_template('profile.html', username=current_user.username)


@main.route('/map')
@login_required
def map_page():
    return render_template('map.html', username=current_user.username)

@main.route('/api/rocks')
@login_required
def get_rock_data():
    
    import csv, os
    from flask import jsonify, current_app
    
    rock_data = []
    csv_path = os.path.join(current_app.root_path, 'rock_info1.csv')
    with open(csv_path, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            try:
                lat = float(row['latitude'])
                lon = float(row['longitude'])
                if lat == 0 or lon == 0 or not row['rocks'].strip():
                    continue
                rock_data.append({
                    "Id": row.get('id'),
                    "Place": row.get('place'),
                    "Rocks": row.get('rocks'),
                    "Latitude": lat,
                    "Longitude": lon
                })
            except Exception:
                continue
    return jsonify(rock_data)

