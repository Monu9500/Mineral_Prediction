// // ✅ FULL UPDATED script.js

// let map = null;
// let rockData = [];
// let filteredRocks = [];
// let markers = [];
// let searchTerm = "";

// const L = window.L;

// // DOM Elements
// const searchForm = document.getElementById("searchForm");
// const searchInput = document.getElementById("searchInput");
// const searchResults = document.getElementById("searchResults");
// const resultsCount = document.getElementById("resultsCount");
// const clearSearchBtn = document.getElementById("clearSearch");
// const gpsToggle = document.getElementById("gpsToggle");
// const resetViewBtn = document.getElementById("resetView");
// const locationCount = document.getElementById("locationCount");
// const searchTermSpan = document.getElementById("searchTerm");
// const mapStatus = document.getElementById("mapStatus");
// const loadingOverlay = document.getElementById("loadingOverlay");
// const errorOverlay = document.getElementById("errorOverlay");
// const errorMessage = document.getElementById("errorMessage");
// const retryButton = document.getElementById("retryButton");
// const attemptCounter = document.getElementById("attemptCounter");

// let initAttempts = 0;
// let userMarker = null;
// let gpsEnabled = false;

// // Load map on DOMContentLoaded
// window.addEventListener("DOMContentLoaded", async () => {
//   try {
//     await initializeMap();
//     await loadRockData();
//     setupEventListeners();
//     hideLoading();
//   } catch (error) {
//     console.error("Init error:", error);
//     showError(error.message);
//   }
// });

// function initializeMap() {
//   return new Promise((resolve, reject) => {
//     initAttempts++;
//     updateAttemptCounter();

//     if (!L) return reject("Leaflet not loaded");

//     const container = document.getElementById("map");
//     if (!container) return reject("Map container missing");

//     map = L.map("map", {
//       center: [20, 0],
//       zoom: 2,
//       zoomControl: false,
//     });

//     L.control.zoom({
//       position: "bottomright"
//     }).addTo(map);

//     L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
//       attribution: '&copy; OpenStreetMap contributors'
//     }).addTo(map);

//     showMapStatus();
//     setTimeout(() => map.invalidateSize(), 100);
//     resolve();
//   });
// }

// async function loadRockData() {
//   try {
//     const res = await fetch("/api/rocks", { credentials: "include" });
//     const data = await res.json();
//     rockData = data;
//     filteredRocks = [];
//     updateLocationCount();
//   } catch (err) {
//     console.error("Failed to load rocks:", err);
//     showError("Failed to load rock data");
//   }
// }

// function showRockLocations(rocks) {
//   clearRockMarkers();

//   if (!rocks.length) return;

//   const customIcon = L.icon({
//     iconUrl: "https://maps.gstatic.com/mapfiles/ms2/micons/red-dot.png",
//     iconSize: [32, 32],
//     iconAnchor: [16, 32],
//     popupAnchor: [0, -30],
//   });

//   markers = rocks.map((r) => {
//     if (!r.Latitude || !r.Longitude) return null;
//     const m = L.marker([r.Latitude, r.Longitude], { icon: customIcon })
//       .addTo(map)
//       .bindPopup(`<strong>${r.Rocks}</strong><br/>${r.Place}`);
//     return m;
//   }).filter(Boolean);

//   if (markers.length > 0) {
//     const group = new L.featureGroup(markers);
//     map.fitBounds(group.getBounds().pad(0.2));
//   }
// }

// function clearRockMarkers() {
//   markers.forEach((m) => map.removeLayer(m));
//   markers = [];
// }

// function setupEventListeners() {
//   searchForm.addEventListener("submit", handleSearch);
//   clearSearchBtn.addEventListener("click", clearSearch);
//   gpsToggle.addEventListener("click", handleGpsToggle);
//   resetViewBtn.addEventListener("click", () => {
//     map.setView([20, 0], 2);
//     clearRockMarkers();
//     filteredRocks = [];
//     updateLocationCount();
//   });
//   retryButton.addEventListener("click", () => window.location.reload());
// }

// function handleSearch(e) {
//   e.preventDefault();
//   searchTerm = searchInput.value.trim().toLowerCase();
//   if (!searchTerm) return;

//   filteredRocks = rockData.filter(r => r.Rocks.toLowerCase().includes(searchTerm));
//   clearRockMarkers();
//   showRockLocations(filteredRocks);
//   showSearchResults();
//   updateLocationCount();
// }

// function clearSearch() {
//   searchInput.value = "";
//   filteredRocks = [];
//   clearRockMarkers();
//   hideSearchResults();
//   updateLocationCount();
//   map.setView([20, 0], 2);
// }

// function updateLocationCount() {
//   locationCount.textContent = `${filteredRocks.length} rock locations`;
// }

// function showMapStatus() {
//   mapStatus.classList.remove("hidden");
// }

// function hideLoading() {
//   loadingOverlay.classList.add("hidden");
// }

// function showError(msg) {
//   loadingOverlay.classList.add("hidden");
//   errorOverlay.classList.remove("hidden");
//   errorMessage.textContent = msg;
// }

// function updateAttemptCounter() {
//   attemptCounter.textContent = `Attempt ${initAttempts}`;
// }

// function showSearchResults() {
//   searchResults.classList.remove("hidden");
//   resultsCount.textContent = `${filteredRocks.length} locations found`;
//   searchTermSpan.textContent = `for \"${searchTerm}\"`;
//   searchTermSpan.classList.remove("hidden");
// }

// function hideSearchResults() {
//   searchResults.classList.add("hidden");
//   searchTermSpan.classList.add("hidden");
// }

// function handleGpsToggle() {
//   if (!navigator.geolocation) {
//     alert("Geolocation not supported");
//     return;
//   }
//   if (!gpsEnabled) {
//     navigator.geolocation.getCurrentPosition((pos) => {
//       const { latitude, longitude } = pos.coords;
//       gpsEnabled = true;

//       if (userMarker) map.removeLayer(userMarker);

//       userMarker = L.circleMarker([latitude, longitude], {
//         radius: 8,
//         fillColor: "#38bdf8",
//         fillOpacity: 0.8,
//         color: "#1e40af",
//         weight: 2
//       }).addTo(map).bindPopup("You are here").openPopup();

//       map.setView([latitude, longitude], 10);
//       gpsToggle.innerHTML = "GPS On";
//     }, () => alert("Unable to retrieve location"));
//   } else {
//     gpsEnabled = false;
//     if (userMarker) map.removeLayer(userMarker);
//     gpsToggle.innerHTML = "GPS Off";
//     map.setView([20, 0], 2);
//   }
// }




// ✅ FINAL UPDATED script.js for Flask + Rock Map App

let map = null;
let rockData = [];
let filteredRocks = [];
let markers = [];
let searchTerm = "";
let initAttempts = 0;
let userMarker = null;
let gpsEnabled = false;

const L = window.L;

// DOM Elements
const searchForm = document.getElementById("searchForm");
const searchInput = document.getElementById("searchInput");
const searchResults = document.getElementById("searchResults");
const resultsCount = document.getElementById("resultsCount");
const clearSearchBtn = document.getElementById("clearSearch");
const gpsToggle = document.getElementById("gpsToggle");
const resetViewBtn = document.getElementById("resetView");
const locationCount = document.getElementById("locationCount");
const searchTermSpan = document.getElementById("searchTerm");
const mapStatus = document.getElementById("mapStatus");
const loadingOverlay = document.getElementById("loadingOverlay");
const errorOverlay = document.getElementById("errorOverlay");
const errorMessage = document.getElementById("errorMessage");
const retryButton = document.getElementById("retryButton");
const attemptCounter = document.getElementById("attemptCounter");

// Initialize map on DOM ready
window.addEventListener("DOMContentLoaded", async () => {
  try {
    await initializeMap();
    await loadRockData();
    setupEventListeners();
    hideLoading();
  } catch (error) {
    console.error("Init error:", error);
    showError(error.message);
  }
});

function initializeMap() {
  return new Promise((resolve, reject) => {
    initAttempts++;
    updateAttemptCounter();

    const container = document.getElementById("map");
    if (!container) return reject("Map container missing");

    map = L.map("map", {
    center: [20, 0],
    zoom: 2,
    zoomControl: false  // Disable default zoom control position
    });

    // ⬇️ Add zoom control manually at bottom left
    L.control.zoom({ position: 'bottomright' }).addTo(map);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    showMapStatus();
    setTimeout(() => map.invalidateSize(), 100);
    resolve();
  });
}

async function loadRockData() {
  try {
    const res = await fetch("/api/rocks", { credentials: "include" });
    const data = await res.json();
    rockData = data;
    filteredRocks = data;
    updateLocationCount();
    // Don't show all by default
  } catch (err) {
    console.error("Failed to load rocks:", err);
    showError("Failed to load rock data");
  }
}

function showRockLocations(rocks) {
  clearRockMarkers();
  if (!rocks.length) return;

  const customIcon = L.icon({
    iconUrl: "https://maps.gstatic.com/mapfiles/ms2/micons/red-dot.png",
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -30],
  });

  markers = rocks.map((r) => {
    if (!r.Latitude || !r.Longitude) return null;
    const m = L.marker([r.Latitude, r.Longitude], { icon: customIcon })
      .addTo(map)
      .bindPopup(`<strong>${r.Rocks}</strong><br/>${r.Place}`);
    return m;
  }).filter(Boolean);

  if (markers.length > 0) {
    const group = new L.featureGroup(markers);
    map.fitBounds(group.getBounds().pad(0.2));
  }
}

function clearRockMarkers() {
  markers.forEach((m) => map.removeLayer(m));
  markers = [];
}

function setupEventListeners() {
  if (searchForm) searchForm.addEventListener("submit", handleSearch);
  if (clearSearchBtn) clearSearchBtn.addEventListener("click", clearSearch);
  if (gpsToggle) gpsToggle.addEventListener("click", handleGpsToggle);
  if (resetViewBtn) resetViewBtn.addEventListener("click", () => {
    map.setView([20, 0], 2);
    clearRockMarkers();
    updateLocationCount();
  });
  if (retryButton) retryButton.addEventListener("click", () => window.location.reload());
}

function handleSearch(e) {
  e.preventDefault();
  searchTerm = searchInput.value.trim().toLowerCase();
  if (!searchTerm) {
    filteredRocks = rockData;
    clearSearch();
    return;
  }
  filteredRocks = rockData.filter(r => r.Rocks.toLowerCase().includes(searchTerm));
  clearRockMarkers();
  showRockLocations(filteredRocks);
  showSearchResults();
  updateLocationCount();
}

function clearSearch() {
  searchInput.value = "";
  filteredRocks = rockData;
  clearRockMarkers();
  hideSearchResults();
  updateLocationCount();
  map.setView([20, 0], 2);
}

function updateLocationCount() {
  locationCount.textContent = `${filteredRocks.length} rock locations`;
}

function showMapStatus() {
  mapStatus.classList.remove("hidden");
}

function hideLoading() {
  loadingOverlay.classList.add("hidden");
}

function showError(msg) {
  loadingOverlay.classList.add("hidden");
  errorOverlay.classList.remove("hidden");
  errorMessage.textContent = msg;
}

function updateAttemptCounter() {
  attemptCounter.textContent = `Attempt ${initAttempts}`;
}

function showSearchResults() {
  searchResults.classList.remove("hidden");
  resultsCount.textContent = `${filteredRocks.length} locations found`;
  searchTermSpan.textContent = `for "${searchTerm}"`;
  searchTermSpan.classList.remove("hidden");
}

function hideSearchResults() {
  searchResults.classList.add("hidden");
  searchTermSpan.classList.add("hidden");
}

function handleGpsToggle() {
  if (!navigator.geolocation) {
    alert("Geolocation not supported");
    return;
  }
  if (!gpsEnabled) {
    navigator.geolocation.getCurrentPosition((pos) => {
      const { latitude, longitude } = pos.coords;
      gpsEnabled = true;

      if (userMarker) map.removeLayer(userMarker);

      userMarker = L.circleMarker([latitude, longitude], {
        radius: 8,
        fillColor: "#38bdf8",
        fillOpacity: 0.8,
        color: "#1e40af",
        weight: 2
      }).addTo(map).bindPopup("You are here").openPopup();

      map.setView([latitude, longitude], 10);

      gpsToggle.classList.remove("bg-white", "border", "border-gray-300");
      gpsToggle.classList.add("bg-green-500", "text-white");
      gpsToggle.innerHTML = "<svg class='h-4 w-4 inline-block mr-1' fill='none' stroke='currentColor' viewBox='0 0 24 24'><polygon points='3,11 22,2 13,21 11,13 3,11'></polygon></svg> GPS On";

    }, () => alert("Unable to retrieve location"));
  } else {
    gpsEnabled = false;
    if (userMarker) map.removeLayer(userMarker);

    gpsToggle.classList.add("bg-white", "border", "border-gray-300");
    gpsToggle.classList.remove("bg-green-500", "text-white");
    gpsToggle.innerHTML = "<svg class='h-4 w-4 inline-block mr-1' fill='none' stroke='currentColor' viewBox='0 0 24 24'><polygon points='3,11 22,2 13,21 11,13 3,11'></polygon></svg> GPS Off";

    map.setView([20, 0], 2);
  }
}
